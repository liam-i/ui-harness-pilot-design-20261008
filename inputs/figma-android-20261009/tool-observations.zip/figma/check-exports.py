"""Validate real Figma exports; no approval or Android runtime claim."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile

from PIL import Image

NODES = {
    'small-f100-menu-default': '2:1807',
    'small-f100-menu-resumable': '2:1835',
    'small-f100-menu-zero-empty': '2:1863',
    'small-f100-menu-zero-resumable': '2:1891',
    'small-f100-dialog-reset-empty': '2:1919',
    'small-f100-dialog-reset-resumable': '2:1959',
    'small-f100-session-active': '2:1999',
    'small-f130-menu-default': '2:2023',
    'small-f130-dialog-reset-empty': '4:103',
    'small-f130-session-active': '4:129',
    'regular-f100-menu-default': '2:2051',
    'regular-f100-dialog-reset-empty': '2:2079',
    'regular-f100-session-active': '2:2119',
    'regular-f130-menu-default': '4:152',
    'regular-f130-dialog-reset-empty': '4:174',
    'regular-f130-session-active': '4:200',
    'asset-arrow': '4:289',
    'asset-reset': '4:291',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--exports', required=True, type=Path)
    parser.add_argument('--reread', required=True, type=Path)
    parser.add_argument('--native-source', required=True, type=Path)
    parser.add_argument('--version-id', required=True)
    args = parser.parse_args()
    names = {name + ext for name in NODES for ext in ('.png', '.svg')}
    for root in (args.exports, args.reread):
        assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == names
        assert not any(p.is_symlink() for p in root.rglob('*'))
    entries = []
    for name in sorted(names):
        path = args.exports / name
        data = path.read_bytes()
        assert data == (args.reread / name).read_bytes(), name
        asset = path.stem.startswith('asset-')
        size = (72, 72) if asset else ((360, 640) if name.startswith('small-') else (412, 915))
        entry = {'file': name, 'bytes': len(data), 'sha256': sha(data), 'source_node': NODES[path.stem]}
        if path.suffix == '.png':
            with Image.open(path) as image:
                image.load()
                assert image.format == 'PNG' and image.size == size, name
                entry['dimensions_px'] = list(image.size)
                if asset:
                    assert image.mode == 'RGBA' and image.getchannel('A').getextrema()[0] == 0
        else:
            text = data.decode('utf-8')
            root = ET.fromstring(text)
            svg_size = (24, 24) if asset else size
            assert (int(root.attrib['width']), int(root.attrib['height'])) == svg_size
            for node in root.iter():
                tag = node.tag.split('}')[-1]
                assert tag not in {'script', 'foreignObject', 'image', 'text'}, (name, tag)
                for key, value in node.attrib.items():
                    assert not key.lower().startswith('on'), (name, key)
                    if key.split('}')[-1] == 'href':
                        assert value.startswith('#'), (name, key)
                    for match in re.findall(r'url\((.*?)\)', value):
                        assert match.strip(' \"\'').startswith('#'), (name, match)
            assert '@import' not in text and '@font-face' not in text
            if not asset:
                suffix = NODES[path.stem].replace(':', '_')
                assert f'clip0_{suffix}' in text, name
            entry['viewBox'] = root.attrib['viewBox']
        entries.append(entry)
    with zipfile.ZipFile(args.native_source) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {'canvas.fig', 'thumbnail.png', 'meta.json', 'images/'}
        assert len(archive.read('canvas.fig')) > 1000
        meta = json.loads(archive.read('meta.json'))
        assert meta['file_name'] == 'Harness · Android Menu · 2026-10-09'
        assert meta['developer_related_links'] == []
    print(json.dumps({
        'checked_at': datetime.now(timezone.utc).isoformat(),
        'result': 'PASS',
        'scope': '36 actual exports, media decode, no external SVG media, supplied re-export byte equality and native archive CRC; source/version context is recorded separately; no human approval or runtime validation',
        'files': entries,
        'source_file': {'sha256': sha(args.native_source.read_bytes()), 'bytes': args.native_source.stat().st_size, 'exported_at': meta['exported_at']},
        'candidate_version_id': args.version_id,
        'approved': False,
        'device_tests_run': 0,
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
