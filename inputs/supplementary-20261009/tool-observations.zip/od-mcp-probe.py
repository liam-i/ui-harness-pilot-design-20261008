import argparse
import json
import os
from pathlib import Path
import selectors
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('requests', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
assert not args.output.exists(), 'retain previous probe; select a new output'
env = dict(os.environ)
env.update(OD_DATA_DIR='/private/tmp/ui-reconciliation-20261009-kd2a3glf/open-design-data', ELECTRON_RUN_AS_NODE='1')
command = ['/Applications/Open Design.app/Contents/MacOS/Open Design',
           '/Applications/Open Design.app/Contents/Resources/app/prebundled/daemon/daemon-cli.mjs',
           'mcp', '--daemon-url', 'http://127.0.0.1:17651']
trace = {'command': command, 'data_directory': env['OD_DATA_DIR'], 'exchanges': []}
stderr_path = args.output.with_suffix('.stderr')
with stderr_path.open('wb') as err:
    process = subprocess.Popen(command, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err)
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)
    buffer = b''

    def send(message):
        process.stdin.write((json.dumps(message, ensure_ascii=False) + '\n').encode())
        process.stdin.flush()

    def call(number, method, params):
        global buffer
        request = {'jsonrpc': '2.0', 'id': number, 'method': method, 'params': params}
        send(request)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            while b'\n' in buffer:
                line, buffer = buffer.split(b'\n', 1)
                if not line.strip():
                    continue
                response = json.loads(line)
                if response.get('id') == number:
                    trace['exchanges'].append({'request': request, 'response': response})
                    return response
                trace.setdefault('notifications', []).append(response)
            events = selector.select(max(0, deadline-time.monotonic()))
            if events:
                data = os.read(process.stdout.fileno(), 65536)
                if not data:
                    raise RuntimeError('MCP process ended before response')
                buffer += data
        raise TimeoutError(f'MCP {method} exceeded 30 seconds')

    try:
        init = call(1, 'initialize', {'protocolVersion': '2024-11-05', 'capabilities': {},
                                    'clientInfo': {'name': 'harness-supplementary-probe', 'version': '1.0'}})
        assert 'result' in init, init
        send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        for index, request in enumerate(json.loads(args.requests.read_text()), 2):
            call(index, request['method'], request.get('params', {}))
        trace['transport_completed'] = True
    except Exception as e:
        trace['transport_completed'] = False
        trace['error'] = str(e)
    finally:
        process.stdin.close()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.terminate()
            process.wait(timeout=5)
        trace['client_exit'] = process.returncode
        args.output.write_text(json.dumps(trace, ensure_ascii=False, indent=2)+'\n')
        print(json.dumps({'transport_completed': trace['transport_completed'], 'exchanges': len(trace['exchanges']),
                          'record': str(args.output), 'error': trace.get('error')}))
