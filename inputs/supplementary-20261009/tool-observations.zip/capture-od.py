"""Capture this pilot's complete MCP artifact plus local raw media; no approval."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json

def artifact_from_trace(trace_path):
    trace=json.loads(trace_path.read_text())
    responses=[x['response']['result'] for x in trace['exchanges']
               if x['request'].get('params',{}).get('name')=='get_artifact']
    assert len(responses)==1 and not responses[0].get('isError'), 'MCP response failed or ambiguous'
    texts=[c['text'] for c in responses[0]['content'] if c['type']=='text']
    assert len(texts)==1, 'expected one artifact JSON'
    return json.loads(texts[0])

def capture(artifact, source):
    if artifact.get('truncated') is not False or artifact.get('skippedFileCount')!=0:
        raise ValueError('incomplete MCP artifact: truncated or skipped files')
    if artifact.get('projectId')!='harness-simulator-menu-20261009':
        raise ValueError('wrong pilot project identity')
    files=artifact['files'];names=[f['name'] for f in files]
    if len(names)!=len(set(x.casefold() for x in names)) or artifact['entryFile'] not in names:
        raise ValueError('duplicate paths or missing entry')
    result={};before={}
    for item in files:
        name=item['name'];path=PurePosixPath(name)
        if path.is_absolute() or '\\' in name or any(x in ['.','..'] for x in name.split('/')):
            raise ValueError('unsafe artifact path')
        local=source.joinpath(*path.parts)
        if local.resolve()!=local.absolute() or not local.is_file():
            raise ValueError('missing media or symlink: '+name)
        data=local.read_bytes()
        if len(data)!=item['size']:raise ValueError('source size changed: '+name)
        if item['binary']:
            if item.get('content') is not None:raise ValueError('unexpected binary transport contract')
        elif item.get('content')!=data.decode('utf-8'):
            raise ValueError('MCP/source text mismatch: '+name)
        before[name]=hashlib.sha256(data).hexdigest();result[name]=data
    if any(hashlib.sha256((source/name).read_bytes()).hexdigest()!=digest for name,digest in before.items()):
        raise ValueError('source changed during capture')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('trace',type=Path);p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args()
    assert not a.output.exists(),'select a new capture directory'
    data=capture(artifact_from_trace(a.trace),a.source.resolve(strict=True))
    a.output.mkdir()
    for name,value in data.items():
        dest=a.output/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(value)
    print(json.dumps({'files':len(data),'binary_media':sum(name.endswith('.png') for name in data),'approved':False}))
